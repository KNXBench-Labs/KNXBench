# Sources and reproduction

These original fictional demo definitions and tooling keep KNXBench's existing AGPL-3.0-or-later terms; see LICENSE. No third-party manufacturer content is included.

The source/ directory includes the original descriptors and generator sources. The Rust writer depends on the KNXBench workspace, not external-format-shaped SQL.

To rebuild, use the repository source_base in manifest.json, overlay the included source files, and run `python3 tools/community_demos.py build NEW_OUTPUT_DIRECTORY` with the repository's Cargo.lock/toolchain. The complete KNXBench source is in KNXBench-Labs/KNXBench; no application binary is included here.

Generator digests bind this uncommitted local review candidate; source_base is its application base, not a claim that the generator was already published in that commit.
